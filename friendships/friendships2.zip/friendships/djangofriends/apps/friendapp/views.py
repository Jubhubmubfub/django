from django.shortcuts import render
from .models import Friendships, Users
# Create your views here.
def index(req):
    users1 = Users.objects.all()
    users2 = Users.objects.filter(last_name='Rodriguez')
    users3 = Users.objects.exclude(last_name='Rodriguez')
    users4 = Users.objects.filter(last_name='Rodriguez') | Users.objects.filter(first_name='Daniel')
    users5 = Users.objects.filter(last_name='Rodriguez').exclude(first_name='Madison')
    users6 = Users.objects.all().exclude(first_name='Daniel').exclude(first_name='Michael')
    users7 = Users.objects.get(id=1)
    users8 = Users.objects.all().order_by('first_name')
    users9 = Users.objects.all().order_by('-last_name')

    friendships = Friendships.objects.all()
    friendships2 = Friendships.objects.filter(user__id=4)
    friendships3 = Friendships.objects.exclude(user__id=4).exclude(user__id=5).exclude(user__id=6)
    friendships4 = Friendships.objects.all()
    friendships5 = Friendships.objects.filter(user__first_name="Michael")
    friendships6 = Friendships.objects.exclude(user__first_name="Daniel")
    friendships7 = Friendships.objects.filter(user__id=1).order_by('friend__first_name').distinct() | Friendships.objects.filter(user__last_name="Hernandez").order_by('friend__first_name').distinct()


    users = Users.objects.filter(usersfriend__friend__id=2)
    print "****************"
    print (users.query)
    print "****************"

    

    context = {'friendships':friendships7,'users':users}
    return render(req, "friendapp/index.html",context)
