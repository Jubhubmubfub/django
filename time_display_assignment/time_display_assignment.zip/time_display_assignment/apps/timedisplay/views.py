from django.shortcuts import render, HttpResponse
import datetime

# Create your views here.

def index(request):
    return render(request, 'timedisplay/index.html')

def displayTime(request):

    currentTime = datetime.datetime.now()
    print datetime.datetime
    print "hahah"
    print currentTime
    print "hahah"
    time = {
    "time":currentTime
    }
    return render(request,'timedisplay/index.html',time)
